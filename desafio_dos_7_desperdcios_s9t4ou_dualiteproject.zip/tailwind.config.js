/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        'brand-primary': '#D62D20', // Toyota Red
        'brand-secondary': '#222222', // Dark Gray/Black for text
        'brand-light': '#F5F5F5', // Light Gray for background
        'brand-dark': '#111111', // Almost Black for dark mode bg
        'brand-dark-text': '#E5E5E5', // Light gray for dark mode text
      },
      fontFamily: {
        sans: ['"Inter"', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
