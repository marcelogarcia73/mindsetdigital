import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Users, ArrowRight } from 'lucide-react';

interface IdentificationScreenProps {
  onStartChallenge: (groupName: string, members: string) => void;
}

const IdentificationScreen: React.FC<IdentificationScreenProps> = ({ onStartChallenge }) => {
  const [groupName, setGroupName] = useState('');
  const [members, setMembers] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (groupName.trim() && members.trim()) {
      onStartChallenge(groupName, members);
    }
  };

  return (
    <motion.div
      key="identification"
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -100 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center min-h-screen p-4"
    >
      <div className="bg-white dark:bg-slate-800/50 p-8 md:p-12 rounded-2xl shadow-xl max-w-lg w-full">
        <div className="text-center mb-8">
          <Users className="mx-auto text-brand-primary mb-2" size={48} />
          <h1 className="text-3xl font-bold text-brand-secondary dark:text-white">Identificação do Grupo</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Registre sua equipe para começar.</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="groupName" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Nome do grupo</label>
            <input
              id="groupName"
              type="text"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              placeholder="Ex: Equipe Lean Masters"
              className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm"
              required
            />
          </div>
          <div>
            <label htmlFor="members" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Integrantes (separados por vírgula)</label>
            <input
              id="members"
              type="text"
              value={members}
              onChange={(e) => setMembers(e.target.value)}
              placeholder="Ex: João, Maria, Carlos"
              className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm"
              required
            />
          </div>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="submit"
            disabled={!groupName.trim() || !members.trim()}
            className="w-full flex justify-center items-center gap-2 py-3 px-4 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-brand-primary hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-primary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Ir para o Sorteio <ArrowRight size={20} />
          </motion.button>
        </form>
      </div>
    </motion.div>
  );
};

export default IdentificationScreen;
