import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '../../lib/supabaseClient';
import { wastes } from '../../lib/data';
import { Loader2, LogOut, Users, MessageSquare, Image as ImageIcon } from 'lucide-react';

interface SubmissionData {
  id: number;
  reflection: string;
  photo_url: string | null;
  created_at: string;
  waste_id: string;
  group_id: number;
}

interface GroupData {
  id: number;
  name: string;
  members: string;
  created_at: string;
  submissions: SubmissionData[];
}

interface AdminDashboardScreenProps {
  onLogout: () => void;
}

const AdminDashboardScreen: React.FC<AdminDashboardScreenProps> = ({ onLogout }) => {
  const [groups, setGroups] = useState<GroupData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAdminData = async () => {
      if (!supabase) {
        setError('Supabase não está conectado.');
        setIsLoading(false);
        return;
      }

      setIsLoading(true);
      setError(null);

      const { data: groupsData, error: groupsError } = await supabase
        .from('groups')
        .select('*')
        .order('created_at', { ascending: false });

      if (groupsError) {
        setError(groupsError.message);
        setIsLoading(false);
        return;
      }

      const { data: submissionsData, error: submissionsError } = await supabase
        .from('submissions')
        .select('*');
      
      if (submissionsError) {
        setError(submissionsError.message);
        setIsLoading(false);
        return;
      }

      const combinedData = groupsData.map(group => ({
        ...group,
        submissions: submissionsData.filter(sub => sub.group_id === group.id)
      }));

      setGroups(combinedData);
      setIsLoading(false);
    };

    fetchAdminData();
  }, []);

  const getWasteTitle = (wasteId: string) => {
    return wastes.find(w => w.id === wasteId)?.title || 'Desconhecido';
  };

  return (
    <motion.div
      key="admin-dashboard"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen w-full p-4 sm:p-8"
    >
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl sm:text-4xl font-extrabold text-brand-secondary dark:text-white">
            Painel do Administrador
          </h1>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onLogout}
            className="flex items-center gap-2 px-4 py-2 bg-slate-600 hover:bg-slate-700 text-white font-bold rounded-lg shadow-md transition-colors"
          >
            <LogOut size={18} />
            Sair
          </motion.button>
        </div>

        {isLoading && (
          <div className="flex justify-center items-center h-64">
            <Loader2 size={48} className="animate-spin text-brand-primary" />
          </div>
        )}

        {error && (
          <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md" role="alert">
            <p className="font-bold">Erro ao carregar dados</p>
            <p>{error}</p>
          </div>
        )}

        {!isLoading && !error && (
          <div className="space-y-8">
            {groups.length === 0 ? (
              <p className="text-center text-slate-500 dark:text-slate-400 text-lg">Nenhuma resposta de grupo encontrada ainda.</p>
            ) : (
              groups.map(group => (
                <div key={group.id} className="bg-white dark:bg-slate-800/50 p-6 rounded-2xl shadow-lg">
                  <div className="border-b border-slate-200 dark:border-slate-700 pb-4 mb-4">
                    <h2 className="text-2xl font-bold text-brand-primary">{group.name}</h2>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-slate-500 dark:text-slate-400 mt-1">
                       <span className="flex items-center gap-1.5"><Users size={14} />{group.members}</span>
                       <span className="hidden sm:inline">|</span>
                       <span>{new Date(group.created_at).toLocaleString('pt-BR')}</span>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    {group.submissions.length === 0 ? (
                       <p className="text-slate-500 dark:text-slate-400">Este grupo ainda não enviou respostas.</p>
                    ) : (
                      group.submissions.map(sub => (
                        <div key={sub.id} className="bg-slate-50 dark:bg-slate-900/50 p-4 rounded-lg">
                          <h3 className="font-bold text-lg text-brand-secondary dark:text-white">{getWasteTitle(sub.waste_id)}</h3>
                          <div className="mt-3 space-y-3">
                            <div className="flex items-start gap-3">
                              <MessageSquare size={18} className="text-slate-500 dark:text-slate-400 mt-1 flex-shrink-0" />
                              <blockquote className="text-slate-700 dark:text-slate-300 italic">"{sub.reflection}"</blockquote>
                            </div>
                            {sub.photo_url && (
                              <div className="flex items-start gap-3">
                                <ImageIcon size={18} className="text-slate-500 dark:text-slate-400 mt-1 flex-shrink-0" />
                                <a href={sub.photo_url} target="_blank" rel="noopener noreferrer" className="block">
                                  <img src={sub.photo_url} alt={`Foto para ${getWasteTitle(sub.waste_id)}`} className="rounded-md max-h-40 object-cover hover:opacity-80 transition-opacity" />
                                </a>
                              </div>
                            )}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default AdminDashboardScreen;
