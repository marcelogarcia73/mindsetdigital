import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { Class } from '../../types';
import { Loader2, Plus, Trash2 } from 'lucide-react';

const ClassManager: React.FC = () => {
    const [classes, setClasses] = useState<Class[]>([]);
    const [newClassName, setNewClassName] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchClasses();
    }, []);

    const fetchClasses = async () => {
        setLoading(true);
        const { data, error } = await supabase.from('classes').select('*').order('name');
        if (error) console.error('Error fetching classes:', error);
        else setClasses(data || []);
        setLoading(false);
    };

    const handleAddClass = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newClassName.trim()) return;
        const { error } = await supabase.from('classes').insert({ name: newClassName });
        if (error) console.error('Error adding class:', error);
        else {
            setNewClassName('');
            fetchClasses();
        }
    };

    const handleDeleteClass = async (id: number) => {
        if (!window.confirm('Tem certeza que deseja excluir esta turma? Isso pode afetar usuários associados.')) return;
        const { error } = await supabase.from('classes').delete().eq('id', id);
        if (error) console.error('Error deleting class:', error);
        else fetchClasses();
    };

    return (
        <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-4">Gerenciar Turmas</h2>
            <form onSubmit={handleAddClass} className="flex gap-2 mb-4">
                <input
                    type="text"
                    value={newClassName}
                    onChange={(e) => setNewClassName(e.target.value)}
                    placeholder="Nome da nova turma"
                    className="flex-grow px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md"
                />
                <button type="submit" className="px-4 py-2 bg-brand-primary text-white rounded-md flex items-center gap-2"><Plus size={18}/> Adicionar</button>
            </form>
            {loading ? <Loader2 className="animate-spin"/> : (
                <ul className="space-y-2">
                    {classes.map(c => (
                        <li key={c.id} className="flex justify-between items-center p-2 bg-slate-50 dark:bg-slate-700/50 rounded">
                            <span>{c.name}</span>
                            <button onClick={() => handleDeleteClass(c.id)} className="text-red-500 hover:text-red-700"><Trash2 size={18}/></button>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default ClassManager;
