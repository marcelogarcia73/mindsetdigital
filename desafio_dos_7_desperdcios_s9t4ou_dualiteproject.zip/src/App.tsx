import React from 'react';
import { AnimatePresence } from 'framer-motion';
import useAuth from './hooks/useAuth';
import LoginScreen from './screens/LoginScreen';
import AdminDashboard from './screens/AdminDashboard';
import StudentDashboard from './screens/StudentDashboard';
import { Loader2 } from 'lucide-react';

function App() {
  const { user, userProfile, loading } = useAuth();

  const renderContent = () => {
    if (loading) {
      return (
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="w-12 h-12 text-brand-primary animate-spin" />
        </div>
      );
    }

    if (!user || !userProfile) {
      return <LoginScreen />;
    }

    if (userProfile.role === 'admin') {
      return <AdminDashboard />;
    }

    if (userProfile.role === 'student') {
      return <StudentDashboard userProfile={userProfile} />;
    }

    // Fallback caso o role não seja nenhum dos esperados
    return <LoginScreen />;
  };

  return (
    <main className="min-h-screen w-full bg-brand-light dark:bg-brand-dark text-brand-secondary dark:text-brand-dark-text antialiased">
      <AnimatePresence mode="wait">
        {renderContent()}
      </AnimatePresence>
    </main>
  );
}

export default App;
