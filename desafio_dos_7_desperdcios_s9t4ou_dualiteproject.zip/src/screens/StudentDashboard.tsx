import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '../lib/supabaseClient';
import { Activity, UserProfile } from '../types';
import { Loader2, LogOut, BookOpen, ArrowRight } from 'lucide-react';
import ActivityScreen from './ActivityScreen';

interface StudentDashboardProps {
  userProfile: UserProfile;
}

const StudentDashboard: React.FC<StudentDashboardProps> = ({ userProfile }) => {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedActivity, setSelectedActivity] = useState<Activity | null>(null);

  useEffect(() => {
    const fetchActivities = async () => {
      const { data, error } = await supabase
        .from('activities')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching activities:', error);
      } else {
        setActivities(data);
      }
      setLoading(false);
    };

    fetchActivities();
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  if (selectedActivity) {
    return <ActivityScreen activity={selectedActivity} onBack={() => setSelectedActivity(null)} />;
  }

  return (
    <motion.div
      key="student-dashboard"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen w-full p-4 sm:p-8"
    >
      <div className="max-w-4xl mx-auto">
        <header className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-brand-secondary dark:text-white">
              Olá, {userProfile.full_name.split(' ')[0]}!
            </h1>
            <p className="text-slate-500 dark:text-slate-400">Turma: {userProfile.class_name}</p>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-4 py-2 bg-slate-600 hover:bg-slate-700 text-white font-bold rounded-lg shadow-md transition-colors"
          >
            <LogOut size={18} />
            Sair
          </button>
        </header>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 size={48} className="animate-spin text-brand-primary" />
          </div>
        ) : (
          <div className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
                <BookOpen/>
                Atividades Disponíveis
            </h2>
            {activities.length > 0 ? (
                activities.map((activity, index) => (
                    <motion.div
                        key={activity.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                    >
                        <button 
                            onClick={() => setSelectedActivity(activity)}
                            className="w-full text-left p-6 bg-white dark:bg-slate-800 rounded-lg shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-300 flex justify-between items-center"
                        >
                            <div>
                                <h3 className="font-bold text-xl text-brand-primary">{activity.title}</h3>
                                <p className="text-slate-500 dark:text-slate-400 mt-1">{activity.description}</p>
                            </div>
                            <ArrowRight className="text-brand-primary" size={24}/>
                        </button>
                    </motion.div>
                ))
            ) : (
                <p className="text-center text-slate-500 dark:text-slate-400 text-lg py-10">Nenhuma atividade disponível no momento.</p>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default StudentDashboard;
