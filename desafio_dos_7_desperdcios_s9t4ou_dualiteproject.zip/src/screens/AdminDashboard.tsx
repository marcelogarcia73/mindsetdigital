import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '../lib/supabaseClient';
import { LogOut, Users, BookCopy, ClipboardList, BarChart2 } from 'lucide-react';
import ClassManager from '../components/admin/ClassManager';
import UserManager from '../components/admin/UserManager';
import ActivityManager from '../components/admin/ActivityManager';
import SubmissionsViewer from '../components/admin/SubmissionsViewer';

type AdminTab = 'classes' | 'users' | 'activities' | 'submissions';

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AdminTab>('submissions');

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  const tabs = [
    { id: 'submissions', label: 'Respostas', icon: ClipboardList },
    { id: 'activities', label: 'Atividades', icon: BookCopy },
    { id: 'users', label: 'Usuários', icon: Users },
    { id: 'classes', label: 'Turmas', icon: BarChart2 },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'classes': return <ClassManager />;
      case 'users': return <UserManager />;
      case 'activities': return <ActivityManager />;
      case 'submissions': return <SubmissionsViewer />;
      default: return null;
    }
  };

  return (
    <motion.div
      key="admin-dashboard"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen w-full p-4 sm:p-8"
    >
      <div className="max-w-7xl mx-auto">
        <header className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-8">
          <h1 className="text-3xl sm:text-4xl font-extrabold text-brand-secondary dark:text-white">
            Painel do Administrador
          </h1>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-4 py-2 bg-slate-600 hover:bg-slate-700 text-white font-bold rounded-lg shadow-md transition-colors self-start sm:self-center"
          >
            <LogOut size={18} />
            Sair
          </button>
        </header>

        <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 border-b border-slate-200 dark:border-slate-700 mb-6">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as AdminTab)}
              className={`flex items-center gap-2 pb-3 font-semibold border-b-2 transition-colors ${
                activeTab === tab.id
                  ? 'border-brand-primary text-brand-primary'
                  : 'border-transparent text-slate-500 hover:text-brand-secondary dark:hover:text-slate-300'
              }`}
            >
              <tab.icon size={18} />
              {tab.label}
            </button>
          ))}
        </div>
        
        <div className="mt-6">
            {renderContent()}
        </div>
      </div>
    </motion.div>
  );
};

export default AdminDashboard;
