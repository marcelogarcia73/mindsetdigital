// Tipos que correspondem à nova estrutura do banco de dados

// Representa um usuário no sistema (pode ser admin ou student)
export interface UserProfile {
  id: string; // UUID from Supabase Auth
  full_name: string;
  email: string;
  role: 'admin' | 'student';
  class_id?: number;
  class_name?: string; // Adicionado para conveniência
}

// Representa uma turma
export interface Class {
  id: number;
  name: string;
  created_at: string;
}

// Representa uma atividade ou desafio
export interface Activity {
  id: number;
  title: string;
  description: string;
  created_at: string;
}

// Representa uma pergunta dentro de uma atividade
export interface Question {
  id: number;
  activity_id: number;
  text: string;
  position: number;
}

// Representa a resposta de um usuário a uma pergunta
export interface Submission {
  id: number;
  question_id: number;
  user_id: string;
  reflection: string;
  created_at: string;
  submission_photos: SubmissionPhoto[]; // Aninhado para fácil acesso
}

// Representa uma foto enviada em uma resposta
export interface SubmissionPhoto {
  id: number;
  submission_id: number;
  photo_url: string;
}
