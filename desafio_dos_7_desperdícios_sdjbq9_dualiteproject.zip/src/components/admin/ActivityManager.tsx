import React from 'react';

const ActivityManager: React.FC = () => {
    return (
        <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-4">Gerenciar Atividades e Perguntas</h2>
            <p className="text-slate-500">A interface para criar e editar atividades e perguntas dinamicamente está em desenvolvimento.</p>
             <p className="text-slate-500 mt-2">Atualmente, você pode adicionar novas atividades e perguntas diretamente nas tabelas <strong>activities</strong> e <strong>questions</strong> no seu painel do Supabase.</p>
        </div>
    );
};

export default ActivityManager;
