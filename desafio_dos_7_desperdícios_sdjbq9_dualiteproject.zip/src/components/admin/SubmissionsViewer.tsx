import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { Submission } from '../../types';
import { Loader2, MessageSquare, Image as ImageIcon } from 'lucide-react';

const SubmissionsViewer: React.FC = () => {
    const [submissions, setSubmissions] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchSubmissions();
    }, []);

    const fetchSubmissions = async () => {
        setLoading(true);
        const { data, error } = await supabase
            .from('submissions')
            .select(`
                *,
                users ( full_name, email ),
                questions ( text, activities ( title ) ),
                submission_photos ( photo_url )
            `)
            .order('created_at', { ascending: false });
        
        if (error) console.error('Error fetching submissions:', error);
        else setSubmissions(data || []);
        setLoading(false);
    };

    return (
        <div className="space-y-6">
            {loading ? <Loader2 className="animate-spin" /> : submissions.length === 0 ? <p>Nenhuma resposta encontrada.</p> : (
                submissions.map(sub => (
                    <div key={sub.id} className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-md">
                        <div className="border-b dark:border-slate-700 pb-3 mb-3">
                            <h3 className="font-bold text-lg">{sub.users.full_name} <span className="text-sm font-normal text-slate-500">({sub.users.email})</span></h3>
                            <p className="text-brand-primary font-semibold">{sub.questions.activities.title}</p>
                            <p className="text-sm text-slate-500">{new Date(sub.created_at).toLocaleString('pt-BR')}</p>
                        </div>
                        <p className="font-semibold mb-1">{sub.questions.text}</p>
                        <blockquote className="italic text-slate-600 dark:text-slate-300 flex items-start gap-2">
                            <MessageSquare size={16} className="mt-1 flex-shrink-0"/>
                            "{sub.reflection}"
                        </blockquote>
                        {sub.submission_photos.length > 0 && (
                            <div className="mt-4">
                                <h4 className="font-semibold flex items-center gap-2 mb-2"><ImageIcon size={16}/> Fotos:</h4>
                                <div className="flex flex-wrap gap-2">
                                    {sub.submission_photos.map((photo: any) => (
                                        <a key={photo.photo_url} href={photo.photo_url} target="_blank" rel="noopener noreferrer">
                                            <img src={photo.photo_url} className="w-24 h-24 object-cover rounded-md hover:opacity-80"/>
                                        </a>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                ))
            )}
        </div>
    );
};

export default SubmissionsViewer;
