import React from 'react';

const UserManager: React.FC = () => {
    return (
        <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-4">Gerenciar Usuários</h2>
            <p className="text-slate-500">A funcionalidade de gerenciamento de usuários (criação, edição, exclusão) requer chamadas de API de administrador do Supabase e está planejada para uma próxima versão.</p>
            <p className="text-slate-500 mt-2">Por enquanto, você pode gerenciar os usuários diretamente no painel do Supabase, na seção "Authentication".</p>
        </div>
    );
};

export default UserManager;
