import React from 'react';
import { wastes } from '../../lib/data';
import { Submission } from '../../types';
import { motion } from 'framer-motion';
import { RefreshCw, Award, MessageSquare, Image } from 'lucide-react';

interface SummaryScreenProps {
  onRestart: () => void;
  submissions: Submission[];
}

const SummaryScreen: React.FC<SummaryScreenProps> = ({ onRestart, submissions }) => {

  return (
    <motion.div
      key="summary"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center min-h-screen p-4 sm:p-6"
    >
      <div className="bg-white dark:bg-slate-800/50 p-8 md:p-12 rounded-2xl shadow-xl max-w-4xl w-full">
        <div className="text-center">
            <Award className="mx-auto text-yellow-500 mb-4" size={64} />
            <h1 className="text-4xl md:text-5xl font-extrabold text-brand-secondary dark:text-white">
              Desafio Concluído!
            </h1>
            <p className="mt-3 text-lg text-slate-600 dark:text-slate-300">
              Parabéns ao seu grupo! Aqui está o resumo das suas reflexões.
            </p>
        </div>

        <div className="mt-8 text-left space-y-4">
          {submissions.map((submission, index) => {
            const waste = wastes.find(w => w.id === submission.wasteId);
            if (!waste) return null;

            return (
              <motion.div
                key={submission.wasteId}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-slate-50 dark:bg-slate-900/50 p-4 rounded-lg border-l-4 border-brand-primary"
              >
                <h3 className="font-bold text-lg text-brand-primary">{waste.title}</h3>
                <div className="mt-3 space-y-3">
                  <div className="flex items-start gap-3">
                    <MessageSquare size={18} className="text-slate-500 dark:text-slate-400 mt-1 flex-shrink-0" />
                    <blockquote className="text-slate-700 dark:text-slate-300 italic">"{submission.reflection}"</blockquote>
                  </div>
                  {submission.photoUrl && (
                    <div className="flex items-start gap-3">
                      <Image size={18} className="text-slate-500 dark:text-slate-400 mt-1 flex-shrink-0" />
                      <img src={submission.photoUrl} alt={`Foto para ${waste.title}`} className="rounded-md max-h-48 object-cover" />
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onRestart}
          className="mt-10 px-8 py-3 bg-slate-600 hover:bg-slate-700 text-white font-bold text-lg rounded-full shadow-lg transition-colors duration-300 flex items-center gap-2 mx-auto"
        >
          <RefreshCw size={20} />
          Reiniciar Desafio
        </motion.button>
      </div>
    </motion.div>
  );
};

export default SummaryScreen;
