import React, { useState, useRef } from 'react';
import { Submission, Waste, GroupInfo } from '../../types';
import { motion } from 'framer-motion';
import { Camera, Send, Lightbulb, User, Loader2 } from 'lucide-react';
import { supabase } from '../../lib/supabaseClient';

interface ChallengeScreenProps {
  waste?: Waste;
  groupInfo: GroupInfo;
  onSubmit: (submission: Submission) => void;
}

const ChallengeScreen: React.FC<ChallengeScreenProps> = ({ waste, groupInfo, onSubmit }) => {
  const [reflection, setReflection] = useState('');
  const [photo, setPhoto] = useState<File | undefined>();
  const [photoName, setPhotoName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!waste) {
    return null;
  }

  const handleSubmit = async () => {
    if (!reflection || !waste) return;
    setIsSubmitting(true);

    let photoUrl: string | undefined = undefined;

    if (photo) {
      // Se o Supabase estiver configurado, faz o upload
      if (supabase && groupInfo.id) {
        const filePath = `${groupInfo.id}/${waste.id}-${Date.now()}`;
        const { error: uploadError } = await supabase.storage
          .from('challenge_photos')
          .upload(filePath, photo);

        if (uploadError) {
          console.error('Erro no upload da imagem:', uploadError);
          setIsSubmitting(false);
          // Adicionar feedback para o usuário
          return;
        }

        const { data: urlData } = supabase.storage
          .from('challenge_photos')
          .getPublicUrl(filePath);
        
        photoUrl = urlData.publicUrl;
      } else {
        // Fallback: cria uma URL local temporária para a imagem
        photoUrl = URL.createObjectURL(photo);
        console.warn("Supabase não configurado. Usando URL de imagem local temporária.");
      }
    }

    const newSubmission: Submission = {
      wasteId: waste.id,
      reflection,
      photoUrl,
    };

    await onSubmit(newSubmission);
    setIsSubmitting(false);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setPhoto(file);
      setPhotoName(file.name);
    }
  };

  return (
    <motion.div
      key={waste.id}
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -100 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center min-h-screen p-4 sm:p-6"
    >
      <div className="w-full max-w-2xl bg-white dark:bg-slate-800/50 p-6 sm:p-8 rounded-2xl shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <span className="inline-block bg-red-100 dark:bg-red-900/50 text-brand-primary px-3 py-1 rounded-full text-sm font-semibold">
            {waste.title}
          </span>
          <span className="text-sm font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
            <User size={14} /> {groupInfo.name}
          </span>
        </div>
        <p className="text-slate-600 dark:text-slate-300 text-base sm:text-lg mb-6">
          {waste.description}
        </p>

        <div className="bg-red-50 dark:bg-slate-900/50 p-4 rounded-lg border-l-4 border-brand-primary">
          <h3 className="font-semibold text-brand-secondary dark:text-slate-100 flex items-center gap-2">
            <Lightbulb className="text-brand-primary" size={20} />
            Pergunta para Reflexão
          </h3>
          <p className="text-slate-600 dark:text-slate-300 mt-1">{waste.question}</p>
        </div>

        <div className="mt-6 space-y-6">
          <textarea
            value={reflection}
            onChange={(e) => setReflection(e.target.value)}
            placeholder="Escreva a reflexão do seu grupo aqui..."
            className="w-full h-32 p-3 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent transition"
          />
          
          <div>
            <input
              type="file"
              accept="image/*"
              onChange={handlePhotoUpload}
              ref={fileInputRef}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-slate-100 dark:bg-slate-700 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-600 hover:border-brand-primary transition"
            >
              <Camera size={20} />
              <span>{photoName || 'Enviar foto do grupo'}</span>
            </button>
          </div>

          <motion.button
            whileHover={{ scale: isSubmitting ? 1 : 1.02 }}
            whileTap={{ scale: isSubmitting ? 1 : 0.98 }}
            onClick={handleSubmit}
            disabled={!reflection || isSubmitting}
            className="w-full px-6 py-3 bg-brand-primary text-white font-bold text-lg rounded-lg shadow-md hover:shadow-lg transition-all duration-300 hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <Loader2 size={20} className="animate-spin" />
                <span>Enviando...</span>
              </>
            ) : (
              <>
                <span>Enviar Resposta</span>
                <Send size={20} />
              </>
            )}
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
};

export default ChallengeScreen;
