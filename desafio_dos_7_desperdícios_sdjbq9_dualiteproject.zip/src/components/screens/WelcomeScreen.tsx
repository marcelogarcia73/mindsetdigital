import React from 'react';
import { motion } from 'framer-motion';
import { Play } from 'lucide-react';

interface WelcomeScreenProps {
  onStart: () => void;
  onAdminClick: () => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onStart, onAdminClick }) => {
  return (
    <motion.div
      key="welcome"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-center min-h-screen p-4 text-center"
    >
      <div className="bg-white dark:bg-slate-800/50 p-8 md:p-12 rounded-2xl shadow-xl max-w-2xl w-full">
        <div onClick={onAdminClick} className="cursor-pointer group" title="Acesso do Administrador">
          <h1 className="text-4xl md:text-6xl font-extrabold text-brand-secondary dark:text-white group-hover:text-brand-primary transition-colors">
            Desafio Lean
          </h1>
          <h2 className="text-3xl md:text-5xl font-bold text-brand-primary">7 Desperdícios</h2>
        </div>
        <p className="mt-4 text-lg md:text-xl text-slate-600 dark:text-slate-300">
          Uma jornada interativa para identificar e refletir sobre os princípios Lean. Reúna seu grupo e prepare-se!
        </p>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onStart}
          className="mt-8 px-8 py-4 bg-brand-primary text-white font-bold text-xl rounded-full shadow-lg hover:shadow-xl transition-shadow duration-300 flex items-center gap-2 mx-auto"
        >
          <Play size={24} />
          Começar
        </motion.button>
      </div>
    </motion.div>
  );
};

export default WelcomeScreen;
