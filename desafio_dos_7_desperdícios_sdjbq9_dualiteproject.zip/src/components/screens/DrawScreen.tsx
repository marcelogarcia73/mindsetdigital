import React from 'react';
import { motion } from 'framer-motion';
import { wastes } from '../../lib/data';
import { Submission, Waste } from '../../types';
import { CheckCircle, Circle, Shuffle } from 'lucide-react';

interface DrawScreenProps {
  groupName: string;
  submissions: Submission[];
  onSelectWaste: (waste: Waste) => void;
}

const DrawScreen: React.FC<DrawScreenProps> = ({ groupName, submissions, onSelectWaste }) => {
  const completedWasteIds = new Set(submissions.map(s => s.wasteId));
  const progress = completedWasteIds.size;

  return (
    <motion.div
      key="draw"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center min-h-screen p-4 sm:p-6"
    >
      <div className="w-full max-w-5xl">
        <div className="text-center mb-8">
          <Shuffle className="mx-auto text-brand-primary mb-2" size={48} />
          <h1 className="text-3xl font-bold text-brand-secondary dark:text-white">Olá, {groupName}!</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Sorteie um desperdício para analisar. {progress} de 7 concluídos.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {wastes.map((waste, index) => {
            const isCompleted = completedWasteIds.has(waste.id);
            return (
              <motion.div
                key={waste.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <button
                  onClick={() => onSelectWaste(waste)}
                  disabled={isCompleted}
                  className="w-full h-full text-left p-4 bg-white dark:bg-slate-800 rounded-lg shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-300 disabled:opacity-60 disabled:cursor-not-allowed disabled:transform-none disabled:shadow-md flex flex-col justify-between"
                >
                  <div>
                    <h3 className="font-bold text-lg text-brand-secondary dark:text-white">{waste.title}</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-3">{waste.description}</p>
                  </div>
                  <div className="mt-3 flex items-center justify-end gap-2 text-sm">
                    {isCompleted ? (
                      <>
                        <CheckCircle size={16} className="text-green-500" />
                        <span className="font-semibold text-green-500">Concluído</span>
                      </>
                    ) : (
                      <>
                        <Circle size={16} className="text-slate-400" />
                        <span className="text-slate-500 dark:text-slate-400">Analisar</span>
                      </>
                    )}
                  </div>
                </button>
              </motion.div>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
};

export default DrawScreen;
