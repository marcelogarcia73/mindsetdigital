import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from '../lib/supabaseClient';
import { Activity, Question, UserProfile } from '../types';
import { Loader2, ArrowLeft, Send, Lightbulb, CheckCircle } from 'lucide-react';
import MultiImageUploader from '../components/MultiImageUploader';
import useAuth from '../hooks/useAuth';

interface ActivityScreenProps {
  activity: Activity;
  onBack: () => void;
}

const ActivityScreen: React.FC<ActivityScreenProps> = ({ activity, onBack }) => {
  const { userProfile } = useAuth();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [reflection, setReflection] = useState('');
  const [photos, setPhotos] = useState<File[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);

  useEffect(() => {
    const fetchQuestions = async () => {
      const { data, error } = await supabase
        .from('questions')
        .select('*')
        .eq('activity_id', activity.id)
        .order('position', { ascending: true });

      if (error) {
        console.error('Error fetching questions:', error);
      } else {
        setQuestions(data);
      }
      setLoading(false);
    };
    fetchQuestions();
  }, [activity.id]);

  const handleSubmit = async () => {
    if (!reflection || !userProfile) return;
    setIsSubmitting(true);

    // 1. Criar a submissão de texto
    const { data: submissionData, error: submissionError } = await supabase
      .from('submissions')
      .insert({
        question_id: questions[currentQuestionIndex].id,
        user_id: userProfile.id,
        reflection: reflection,
      })
      .select()
      .single();

    if (submissionError) {
      console.error('Error creating submission:', submissionError);
      setIsSubmitting(false);
      return;
    }

    // 2. Fazer upload das fotos e associá-las
    if (photos.length > 0) {
      for (const photo of photos) {
        const filePath = `${userProfile.id}/${submissionData.id}/${photo.name}`;
        const { error: uploadError } = await supabase.storage
          .from('challenge_photos')
          .upload(filePath, photo);

        if (uploadError) {
          console.error('Upload error:', uploadError);
          continue; // Pula para a próxima foto em caso de erro
        }
        
        const { data: urlData } = supabase.storage.from('challenge_photos').getPublicUrl(filePath);

        await supabase.from('submission_photos').insert({
          submission_id: submissionData.id,
          photo_url: urlData.publicUrl,
        });
      }
    }
    
    // Limpa o estado para a próxima pergunta
    setReflection('');
    setPhotos([]);
    setIsSubmitting(false);

    // Avança para a próxima pergunta ou finaliza
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      setIsCompleted(true);
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center h-screen"><Loader2 className="animate-spin text-brand-primary" size={48} /></div>;
  }
  
  if (isCompleted) {
    return (
        <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center min-h-screen text-center p-4"
        >
            <CheckCircle className="text-green-500" size={80} />
            <h1 className="text-4xl font-bold mt-4">Atividade Concluída!</h1>
            <p className="text-slate-500 dark:text-slate-400 mt-2">Suas respostas foram enviadas com sucesso.</p>
            <button onClick={onBack} className="mt-8 flex items-center gap-2 px-6 py-3 bg-brand-primary text-white font-bold rounded-lg">
                <ArrowLeft size={20} />
                Voltar ao Início
            </button>
        </motion.div>
    )
  }

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <motion.div
      key={activity.id}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="flex flex-col items-center min-h-screen p-4 sm:p-6"
    >
      <div className="w-full max-w-3xl">
        <button onClick={onBack} className="flex items-center gap-2 text-slate-500 dark:text-slate-400 hover:text-brand-primary mb-4">
          <ArrowLeft size={20} />
          Voltar
        </button>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestion?.id || 'loading'}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
            className="bg-white dark:bg-slate-800/50 p-6 sm:p-8 rounded-2xl shadow-xl"
          >
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-brand-primary">{activity.title}</h2>
                <span className="font-semibold">{currentQuestionIndex + 1} / {questions.length}</span>
            </div>
            
            {currentQuestion ? (
                <>
                    <div className="bg-red-50 dark:bg-slate-900/50 p-4 rounded-lg border-l-4 border-brand-primary mb-6">
                        <h3 className="font-semibold text-brand-secondary dark:text-slate-100 flex items-center gap-2">
                            <Lightbulb className="text-brand-primary" size={20} />
                            Pergunta
                        </h3>
                        <p className="text-slate-600 dark:text-slate-300 mt-1 text-lg">{currentQuestion.text}</p>
                    </div>

                    <div className="space-y-6">
                        <textarea
                            value={reflection}
                            onChange={(e) => setReflection(e.target.value)}
                            placeholder="Escreva sua reflexão aqui..."
                            className="w-full h-32 p-3 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-brand-primary"
                        />
                        
                        <MultiImageUploader photos={photos} setPhotos={setPhotos} />

                        <button
                            onClick={handleSubmit}
                            disabled={!reflection || isSubmitting}
                            className="w-full flex justify-center items-center gap-2 py-3 px-4 text-lg font-medium text-white bg-brand-primary rounded-lg shadow-md hover:bg-red-700 disabled:opacity-50"
                        >
                            {isSubmitting ? <Loader2 className="animate-spin" /> : <Send />}
                            {currentQuestionIndex < questions.length - 1 ? 'Enviar e Próxima' : 'Finalizar Atividade'}
                        </button>
                    </div>
                </>
            ) : <p>Nenhuma pergunta encontrada para esta atividade.</p>}
          </motion.div>
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

export default ActivityScreen;
