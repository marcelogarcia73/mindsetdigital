import { Waste } from '../types';

export const wastes: Waste[] = [
  {
    id: 'superproducao',
    title: 'Superprodução',
    description: 'Produzir mais, antes ou mais rápido do que o necessário. É o pior dos desperdícios, pois causa todos os outros.',
    question: 'Como podemos alinhar nossa produção à demanda real para evitar excessos?',
  },
  {
    id: 'espera',
    title: 'Espera',
    description: 'Tempo ocioso de recursos (pessoas ou máquinas) aguardando por materiais, informações, ferramentas ou instruções.',
    question: 'Quais são os principais gargalos que causam espera em nosso processo e como podemos eliminá-los?',
  },
  {
    id: 'transporte',
    title: 'Transporte',
    description: 'Movimentação desnecessária de materiais, produtos ou informações de um local para outro.',
    question: 'De que forma podemos reorganizar nosso layout ou fluxo de trabalho para minimizar o transporte?',
  },
  {
    id: 'processamento',
    title: 'Processamento Excessivo',
    description: 'Realizar mais trabalho do que o necessário para atender às exigências do cliente, como usar equipamentos de alta precisão onde não é preciso.',
    question: 'Existem etapas em nosso processo que são mais complexas do que o necessário? Como podemos simplificá-las?',
  },
  {
    id: 'estoque',
    title: 'Estoque',
    description: 'Manter mais material (matéria-prima, produto em processo ou acabado) do que o mínimo necessário para o fluxo de trabalho.',
    question: 'Como um excesso de estoque esconde outros problemas em nossa operação e como podemos reduzi-lo?',
  },
  {
    id: 'movimento',
    title: 'Movimento',
    description: 'Qualquer movimento de pessoas que não agrega valor ao produto, como procurar ferramentas, andar desnecessariamente ou se abaixar.',
    question: 'Como podemos organizar o espaço de trabalho para que tudo esteja ao alcance e os movimentos desnecessários sejam eliminados?',
  },
  {
    id: 'defeitos',
    title: 'Defeitos',
    description: 'Produção de peças ou serviços que não atendem às especificações, exigindo retrabalho, sucata ou conserto.',
    question: 'Qual é a principal causa de defeitos em nosso trabalho e que medidas podemos tomar para preveni-los na origem?',
  },
];
