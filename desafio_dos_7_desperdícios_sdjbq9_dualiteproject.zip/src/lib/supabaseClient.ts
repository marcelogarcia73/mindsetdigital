import { createClient, SupabaseClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

let supabase: SupabaseClient | null = null;

// Verifica se as variáveis de ambiente existem e são válidas
if (supabaseUrl && supabaseAnonKey && supabaseUrl.startsWith('https')) {
  try {
    supabase = createClient(supabaseUrl, supabaseAnonKey);
  } catch (error) {
    console.error("Falha ao inicializar o cliente Supabase. Verifique suas credenciais.", error);
    supabase = null;
  }
} else {
  console.warn(
    'Credenciais do Supabase não encontradas ou inválidas no arquivo .env. ' +
    'O aplicativo funcionará em modo offline (sem salvar dados permanentemente).'
  );
}

export { supabase };
